cat ../sql/updates/world/*.sql > world_update.sql
cat ../sql/updates/hotfixes/*.sql > hotfixes_update.sql
